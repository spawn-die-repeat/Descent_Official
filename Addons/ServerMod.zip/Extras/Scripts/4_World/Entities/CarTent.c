class SG_DigitalCamo_CarTent extends CarTent {}
class SG_DuckHunter_CarTent extends CarTent {}
class SG_JungleCamo_CarTent extends CarTent {}
class SG_LeafTent_CarTent extends CarTent {}
